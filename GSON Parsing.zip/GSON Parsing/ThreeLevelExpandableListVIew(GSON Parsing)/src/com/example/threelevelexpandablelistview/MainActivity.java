package com.example.threelevelexpandablelistview;

import java.io.Reader;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.CallLog;
import android.widget.ExpandableListView;

import com.example.Vo.DetailsVo;
import com.example.Vo.ShopMasterOntdek;
import com.example.utils.Constants;
import com.example.utils.CustomFieldNamePolicy;
import com.example.utils.WSCaller;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;

public class MainActivity extends Activity {
	public static CustomExpandableListView list;
	private Context m_con;
	private String m_result;
	private Handler m_handler;
	private ArrayList<DetailsVo> m_details;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (android.os.Build.VERSION.SDK_INT > 9) {
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
					.permitAll().build();
			StrictMode.setThreadPolicy(policy);
		}
		setContentView(R.layout.activity_main);
		 m_con = MainActivity.this;
		 Constants.m_context = getApplicationContext();
		 m_handler = new Handler();
//		 m_details = new ArrayList<DetailsVo>();
		// int noObjectsLevel1 = 5;
		// int noObjectsLevel2 = 4;
		// int noObjectsLevel3 = 7;
		//
		// List<Object> objectsLvl1 = new ArrayList<Object>();
		// for (int i = 0; i < noObjectsLevel1; i++) {
		// List<Object> objectsLvl2 = new ArrayList<Object>();
		// for (int j = 0; j < noObjectsLevel2; j++) {
		// List<Object> objectsLvl3 = new ArrayList<Object>();
		// for (int k = 0; k < noObjectsLevel3; k++) {
		// objectsLvl3.add(new Object("lvl3_" + String.valueOf(k),
		// null));
		// }
		// objectsLvl2.add(new Object("lvl2_" + String.valueOf(j),
		// objectsLvl3));
		// }
		// objectsLvl1
		// .add(new Object("lvl1_" + String.valueOf(i), objectsLvl2));
		// }
		//
		// RelativeLayout parent = (RelativeLayout) findViewById(R.id.parent);
		//
		// list = new CustomExpandableListView(this);
		// Adapter adapter = new Adapter(this, objectsLvl1);
		// list.setAdapter(adapter);
		//
		// parent.addView(list);

		// callWS m_ws = new callWS();
		// m_ws.execute();
		callResultWS();

		String[] projection = { "address", "date", "body" };
		String[] strFields = { CallLog.Calls._ID, CallLog.Calls.NUMBER,
				CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE,
				CallLog.Calls.DATE, CallLog.Calls.DURATION };
		// String strOrder = CallLog.Calls.DATE + " DESC";
		// Cursor cursorCall =
		// this.getContentResolver().query(CallLog.Calls.CONTENT_URI, strFields,
		// null, null, strOrder);
		// Cursor cursorInbox =
		// this.getContentResolver().query(SMS_INBOX_CONTENT_URI, projection,
		// null, null, sortOrder);
		// Cursor merged = new MergeCursor(new Cursor[] { cursorCall,
		// cursorInbox });

//		Cursor cursor = this.getContentResolver().query(
//				CallLog.Calls.CONTENT_URI, new String[] { CallLog.Calls.DATE },
//				" GROUP BY " + CallLog.Calls.DATE, null,
//				CallLog.Calls.DATE + " DESC ");
		//
		// if (cursor != null) {
		// cursor.moveToFirst();
		// do {
		// System.err.println("Column Name============"
		// + cursor.getColumnName(0));
		// } while (cursor.moveToNext());
		// }
	}

	public void callResultWS() {
		new WSCaller() {

			protected void onPreExecute() {
				super.onPreExecute();
				CommonUtils.showProgress(m_con, "Please Wait");
			};

			protected void onPostExecute(Reader result) {
				parseJsonResponse(result);
				CommonUtils.dismissDialog();
			};

		}.execute("", "shop", m_con);
	}

	public void parseJsonResponse(final Reader m_response) {
		try {
			m_handler.post(new Runnable() {
				@Override
				public void run() {

					if (m_response != null) {
						Gson m_gson = new GsonBuilder().setFieldNamingStrategy(
								new CustomFieldNamePolicy()).create();
						ShopMasterOntdek m_master = m_gson.fromJson(m_response,
								ShopMasterOntdek.class);
						// if (m_master.winkels != null) {
						// Winkels m_winkls = m_gson.fromJson(m_response,
						// Winkels.class);
						if (m_master.winkels.boekhandel.size() > 0) {
							// if (m_master.winkels.boekhandel != null) {
							// System.err.println("Winkls Size===="
							// + m_master.winkels.boekhandel.size());
							// if (m_winkls.boekhandel.size() > 0) {
							DetailsVo m_vo = null;
							for (int i = 0; i < m_master.winkels.boekhandel
									.size(); i++) {
								m_vo = new DetailsVo();
								System.err.println("Winkls Size===="
										+ m_master.winkels.boekhandel.size()
										+ m_master.winkels.boekhandel.get(i).businessTitle
												.toString());
								m_vo.businessID = m_master.winkels.boekhandel
										.get(i).businessID.toString();
								m_vo.businessTitle = m_master.winkels.boekhandel
										.get(i).businessTitle.toString();
							}
							m_master.winkels.boekhandel.add(m_vo);
						} else if (m_master.winkels.hobbyRecreatie.size() > 0) {
							DetailsVo m_vo = null;
							for (int i = 0; i < m_master.winkels.hobbyRecreatie
									.size(); i++) {
								m_vo = new DetailsVo();
								m_vo.businessID = m_master.winkels.hobbyRecreatie
										.get(i).businessID;
								m_vo.businessTitle = m_master.winkels.hobbyRecreatie
										.get(i).businessTitle;

							}
							m_master.winkels.hobbyRecreatie.add(m_vo);
						} else if (m_master.winkels.damesmode.size() > 0) {
							DetailsVo m_vo = null;
							for (int i = 0; i < m_master.winkels.damesmode
									.size(); i++) {
								m_vo = new DetailsVo();
								m_vo.businessID = m_master.winkels.damesmode
										.get(i).businessID;
								m_vo.businessTitle = m_master.winkels.damesmode
										.get(i).businessTitle;

							}
							m_master.winkels.damesmode.add(m_vo);
						}
					}

				}
			});
		} catch (JsonParseException e) {
		}
	}
}

class CustomExpandableListView extends ExpandableListView {
	public CustomExpandableListView(Context context) {
		super(context);
	}

	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		/*
		 * Adjust height
		 */
		heightMeasureSpec = MeasureSpec.makeMeasureSpec(500,
				MeasureSpec.AT_MOST);
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
	}
}
