package com.example.threelevelexpandablelistview;

import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Movie;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.widget.ListView;

import com.example.Vo.ShopVo;
import com.example.utils.Constants;
import com.example.utils.CustomFieldNamePolicy;
import com.example.utils.WSCaller;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class TestActivity extends Activity {
	// Log tag
	private static final String TAG = MainActivity.class.getSimpleName();

	// Movies json url
	private static final String url = "http://api.androidhive.info/json/movies.json";
	private ProgressDialog pDialog;
	private List<Movie> movieList = new ArrayList<Movie>();
	private ListView listView;
	private CustomListAdapter adapter;
	private Context m_cont;
	private Handler m_handler;
	private ArrayList<ShopVo> m_arrDetails;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (android.os.Build.VERSION.SDK_INT > 9) {
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
					.permitAll().build();
			StrictMode.setThreadPolicy(policy);
		}
		setContentView(R.layout.list_layout);
		m_cont = TestActivity.this;
		Constants.m_context = getApplicationContext();
		m_handler = new Handler();
		m_arrDetails = new ArrayList<ShopVo>();
		listView = (ListView) findViewById(R.id.list);
	
		callListWS();
	
	}

	private void callListWS() {
		new WSCaller() {
			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				CommonUtils.showProgress(m_cont, "Please Wait...");
			}

			@Override
			protected void onPostExecute(Reader result) {
				// TODO Auto-generated method stub
				super.onPostExecute(result);
				parseResponse(result);
				CommonUtils.dismissDialog();
			}
			// http://180.211.110.195/typo3-projects/woerden/webservices/getContent.php?action=CheckIN
		}.execute("", "CheckIN", m_cont);
	}

	private void parseResponse(final Reader p_response) {
		m_handler.post(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				if (p_response != null) {
					Gson m_gson = new GsonBuilder().setFieldNamingStrategy(
							new CustomFieldNamePolicy()).create();
					ShopVo[] m_details = m_gson.fromJson(p_response,
							ShopVo[].class);
					if (m_details != null) {
						ShopVo m_shVo = null;

						for (int i = 0; i < m_details.length; i++) {
							System.err.println("Shope Name======"
									+ m_details[i].m_ShopName
									+ "\n Shop ID======" + m_details[i].m_Id);
							m_shVo = new ShopVo();
							m_shVo.m_Id = m_details[i].m_Id;
							m_shVo.m_ShopName = m_details[i].m_ShopName;
							m_shVo.m_discount_Text = m_details[i].m_discount_Text;
							m_shVo.m_Starred = m_details[i].m_Starred;
							m_arrDetails.add(m_shVo);
						}

					}
					listView.setAdapter(new CustomListAdapter(
							TestActivity.this, m_arrDetails));
				}
			}
		});
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		hidePDialog();
	}

	private void hidePDialog() {
		if (pDialog != null) {
			pDialog.dismiss();
			pDialog = null;
		}
	}

}