package com.example.utils;

import android.content.Context;

public class Constants {
	public static final int TIMEOUT = 5000;
	public static Context m_context;
	public static final int CUSTOM_ERROR_CODE = 1;
	public static final int SYSTEM_ERROR_CODE = 2;
	public static boolean DEBUG = true;
}
