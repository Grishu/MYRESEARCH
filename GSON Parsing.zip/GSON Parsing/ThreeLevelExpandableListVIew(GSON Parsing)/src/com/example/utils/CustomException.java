package com.example.utils;

import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;

/**
 * This is the custom exception handling class and handles all the custom error
 * messages like network problem, invalid user name or password.
 * 
 * @author
 * 
 */
public class CustomException extends Exception implements Serializable
{
	static final long serialVersionUID = 944989401414972391L;
	
	private int m_errorCode;
	private Throwable m_cause;
	private Throwable m_causeLinkedException;
	private String m_errorMessage = "";
	
	public CustomException()
	{
		this(null);
	}
	
	/**
	 * Constructor
	 * 
	 * @param p_message
	 *            error message.
	 */
	public CustomException(String p_message)
	{
		this(p_message, 0);
	}
	
	/**
	 * Constructor
	 * 
	 * @param p_message
	 *            error message.
	 * @param p_errorCode
	 *            error code.
	 */
	public CustomException(String p_message, int p_errorCode)
	{
		this(p_message, p_errorCode, null);
	}
	
	/**
	 * Constructor
	 * 
	 * @param p_message
	 *            error message
	 * @param p_cause
	 *            cuase of the error like Throwable.
	 */
	public CustomException(String p_message, Throwable p_cause)
	{
		this(p_message, 0, p_cause);
	}
	
	/**
	 * Constructor
	 * 
	 * @param p_message
	 *            error message
	 * @param p_errorCode
	 *            error code.
	 * @param p_cause
	 *            cuase of the error like Throwable.
	 */
	public CustomException(String p_message, int p_errorCode, Throwable p_cause)
	{
		this(p_message, p_errorCode, p_cause, p_cause);
	}
	
	/**
	 * Constructor
	 * 
	 * @param p_message
	 *            error message
	 * @param p_errorCode
	 *            error code.
	 * @param p_cause
	 *            cuase of the error like Throwable.
	 * @param p_causeLinkedException
	 *            linked exception
	 */
	public CustomException(String p_message, int p_errorCode, Throwable p_cause, Throwable p_causeLinkedException)
	{
		
		super((p_errorCode != 0) ? (p_errorCode + ": " + p_message) : p_message);
		this.m_errorMessage = p_message;
		m_errorCode = p_errorCode;
		m_cause = p_cause;
		m_causeLinkedException = p_causeLinkedException;
		
	}
	
	/**
	 * gets the error message.
	 * 
	 * @return error message.
	 */
	public String getErrorMessage()
	{
		return m_errorMessage;
	}
	
	/**
	 * sets the error message.
	 * 
	 * @return error message.
	 */
	public void setErrorMessage(String p_errMsg)
	{
		m_errorMessage = p_errMsg;
	}
	
	/**
	 * Converts a stack trace to a <code>String</code> so it can be serialized.
	 * 
	 * @return the stack trace <code>String</code> for the specified
	 *         <code>Throwable</code>.
	 */
	public static String generateStackTraceString(Throwable p_throwable)
	{
		StringWriter stringWriter = new StringWriter();
		p_throwable.printStackTrace(new PrintWriter(stringWriter));
		return stringWriter.toString();
	}
	
	/**
	 * Returns the error code of this exception.
	 * 
	 * @return the error code of this exception.
	 */
	public int getErrorCode()
	{
		return m_errorCode;
	}
	
	/**
	 * Returns the cause of this exception or <code>null</code> if the cause is
	 * nonexistent or unknown.
	 * 
	 * @return the cause of this exception or <code>null</code> if the cause is
	 *         nonexistent or unknown.
	 */
	public Throwable getCause()
	{
		return m_cause;
	}
	
	/**
	 * sets the error cause of this exception.
	 * 
	 * @param p_cause
	 *            Throwable
	 */
	public void setCause(Throwable p_cause)
	{
		m_cause = p_cause;
	}
	
	/**
	 * Returns the stack trace of this and all nested exceptions.
	 * 
	 * @return the stack trace of this and all nested exceptions.
	 */
	public String getStackTraceString()
	{
		StringWriter stringWriter = new StringWriter();
		stringWriter.write(this.getMessage());
		
		Throwable rootCause = getRootCause(m_cause);
		if (rootCause == null)
		{
			printStackTrace(new PrintWriter(stringWriter));
		}
		else
		{
			stringWriter.write("\nCaused by: ");
			rootCause.printStackTrace(new PrintWriter(stringWriter));
		}
		
		if (m_causeLinkedException != null)
		{
			stringWriter.write("\nCaused by: ");
			m_causeLinkedException.printStackTrace(new PrintWriter(stringWriter));
		}
		
		return stringWriter.toString();
	}
	
	/**
	 * Returns the causeLinkedException.
	 * 
	 * @return Throwable
	 */
	public Throwable getCauseLinkedException()
	{
		return m_causeLinkedException;
	}
	
	/**
	 * Sets the causeLinkedException.
	 * 
	 * @param causeLinkedException
	 *            The causeLinkedException to set
	 */
	public void setCauseLinkedException(Throwable p_causeLinkedException)
	{
		m_causeLinkedException = p_causeLinkedException;
	}
	
	/**
	 * Get the root cause of the throwable. As in most of the case only the root
	 * cause would be helpful for diagnosing an issue so in order to reduce the
	 * useless information always get the root cause.
	 * 
	 * @param p_throwable
	 * @return the root cause
	 */
	public static Throwable getRootCause(Throwable p_throwable)
	{
		if (p_throwable == null)
		{
			return null;
		}
		
		Throwable cause = p_throwable.getCause();
		
		return cause == null ? p_throwable : getRootCause(cause);
	}
}
