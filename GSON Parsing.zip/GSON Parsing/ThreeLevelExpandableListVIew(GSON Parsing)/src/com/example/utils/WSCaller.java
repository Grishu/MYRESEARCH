package com.example.utils;

import java.io.Reader;

import android.os.AsyncTask;

public class WSCaller extends AsyncTask<Object,Integer,Reader>
{
	private Reader m_respose;
//	private IActivityListner m_exceptionListner;
	@Override
	protected Reader doInBackground(Object... params)
	{
		m_respose=null;
//		m_exceptionListner=(IActivityListner) params[2];
		try
		{
			m_respose= HttpHelper.getResponse(params[0].toString(),params[1].toString());
		}
		catch (CustomException e)
		{
//			m_exceptionListner.exceptionListner(e);
		}
		return m_respose;
	}
	
}
