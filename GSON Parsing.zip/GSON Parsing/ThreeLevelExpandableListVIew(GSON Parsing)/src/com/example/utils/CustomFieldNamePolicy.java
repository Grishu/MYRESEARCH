package com.example.utils;

import java.lang.reflect.Field;

import com.google.gson.FieldNamingStrategy;

/**
 * Class for change default configuration of Gson to apply a specific naming
 * policy to an object's field during serialization and deserialization.
 * 
 */
public class CustomFieldNamePolicy implements FieldNamingStrategy {

	/**
	 * translate class object name with the json response field during
	 * deserialization.
	 */
	public String translateName(Field p_fieldName) {

		String m_field;
		m_field = p_fieldName.getName();
		if (p_fieldName.getName().equalsIgnoreCase("winkels")) {
			m_field = "Winkels";
		} else if (p_fieldName.getName().equalsIgnoreCase("horeca")) {
			m_field = "Horeca";
		} else if (p_fieldName.getName().equalsIgnoreCase("toerisme")) {
			m_field = "Toerisme";
		} else if (p_fieldName.getName().equalsIgnoreCase("boekhandel")) {
			m_field = "Boekhandel";
		} else if (p_fieldName.getName().equalsIgnoreCase("hobbyRecreatie")) {
			m_field = "Hobby & Recreatie";
		} else if (p_fieldName.getName().equalsIgnoreCase("damesmode")) {
			m_field = "Damesmode";
		} else if (p_fieldName.getName().equalsIgnoreCase("herenmode")) {
			m_field = "Herenmode";
		} else if (p_fieldName.getName().equalsIgnoreCase("kindermode")) {
			m_field = "Kindermode";
		} else if (p_fieldName.getName().equalsIgnoreCase("lifestyle")) {
			m_field = "Lifestyle";
		} else if (p_fieldName.getName().equalsIgnoreCase("verswinkel")) {
			m_field = "Verswinkel";
		} else if (p_fieldName.getName().equalsIgnoreCase("bodyBeauty")) {
			m_field = "Body & Beauty";
		} else if (p_fieldName.getName().equalsIgnoreCase("diensten")) {
			m_field = "Diensten";
		} else if (p_fieldName.getName().equalsIgnoreCase("specialisten")) {
			m_field = "Specialisten";
		} else if (p_fieldName.getName().equalsIgnoreCase("speelgoed")) {
			m_field = "Speelgoed";
		} else if (p_fieldName.getName().equalsIgnoreCase("electronica")) {
			m_field = "Electronica";
		} else if (p_fieldName.getName().equalsIgnoreCase("frans")) {
			m_field = "Frans";
		} else if (p_fieldName.getName().equalsIgnoreCase("hollands")) {
			m_field = "Hollands";
		} else if (p_fieldName.getName().equalsIgnoreCase("aziatisch")) {
			m_field = "Aziatisch";
		} else if (p_fieldName.getName().equalsIgnoreCase("italiaans")) {
			m_field = "Italiaans";
		} else if (p_fieldName.getName().equalsIgnoreCase("spaans")) {
			m_field = "Spaans";
		} else if (p_fieldName.getName().equalsIgnoreCase("cafe")) {
			m_field = "Cafe";
		} else if (p_fieldName.getName().equalsIgnoreCase("broodjesSnacks")) {
			m_field = "Broodjes & Snacks";
		} else if (p_fieldName.getName().equalsIgnoreCase("lunchroom")) {
			m_field = "Lunchroom";
		} else if (p_fieldName.getName().equalsIgnoreCase("grieks")) {
			m_field = "Grieks";
		} else if (p_fieldName.getName().equalsIgnoreCase("zalen")) {
			m_field = "Zalen";
		} else if (p_fieldName.getName().equalsIgnoreCase("fietsen")) {
			m_field = "Fietsen";
		} else if (p_fieldName.getName().equalsIgnoreCase("monument")) {
			m_field = "Monument";
		} else if (p_fieldName.getName().equalsIgnoreCase("wandelen")) {
			m_field = "Wandelen";
		} else if (p_fieldName.getName().equalsIgnoreCase("varen")) {
			m_field = "Varen";
		} else if (p_fieldName.getName().equalsIgnoreCase("bBHotels")) {
			m_field = "B&B Hotels";
		} else if (p_fieldName.getName().equalsIgnoreCase("museum")) {
			m_field = "Museum";
		} else if (p_fieldName.getName().equalsIgnoreCase("cultureel")) {
			m_field = "Cultureel";
		} else if (p_fieldName.getName().equalsIgnoreCase("publiekeruimte")) {
			m_field = "Publiekeruimte";
		} else if (p_fieldName.getName().equalsIgnoreCase("businessTitle")) {
			m_field = "businessTitle";
		} else if (p_fieldName.getName().equalsIgnoreCase("businessID")) {
			m_field = "businessID";
		} else if (p_fieldName.getName().equalsIgnoreCase("m_discount_Text")) {
			m_field = "discount_text";
		} else if (p_fieldName.getName().equalsIgnoreCase("m_Id")) {
			m_field = "id";
		} else if (p_fieldName.getName().equalsIgnoreCase("m_ShopName")) {
			m_field = "shopName";
		} else if (p_fieldName.getName().equalsIgnoreCase("m_Starred")) {
			m_field = "starred";
		}

		return m_field;
	}
}
