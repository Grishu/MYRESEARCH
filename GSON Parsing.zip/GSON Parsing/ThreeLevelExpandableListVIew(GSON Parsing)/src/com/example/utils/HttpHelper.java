package com.example.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.zip.GZIPInputStream;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import com.example.threelevelexpandablelistview.R;

/**
 * Class used to support all the Data Access layer methods like fetching data
 * from the server or storing/retrieving <br>
 * data from the local SQLLite server.
 * 
 * @author
 * 
 */
public class HttpHelper {

	private static String TAG = HttpHelper.class.getSimpleName();
	private static String m_wsUrl = "https://stadshartwoerden.nl/webservices/getContent.php?action=";//"http://180.211.110.195/typo3-projects/woerden/webservices/getContent.php?action=";

	/**
	 * Function for getting HTTP URL connection object.
	 * 
	 * @param p_url
	 *            - Http Url
	 * @return - HttpURLConnection object.
	 * @throws IOException
	 */
	private static HttpURLConnection getHttpUrlConnection(String p_wsUrl)
			throws CustomException {
		try {
			URL m_url = new URL(p_wsUrl);
			HttpURLConnection m_httpConnection = (HttpURLConnection) m_url
					.openConnection();
			m_httpConnection.setReadTimeout(Constants.TIMEOUT);
			m_httpConnection.setConnectTimeout(Constants.TIMEOUT);
			m_httpConnection.setDoOutput(true);
			return m_httpConnection;
		} catch (IOException io) {
			throw new CustomException("Unable to open connection",
					Constants.CUSTOM_ERROR_CODE, io);
		}
	}

	/**
	 * This method check Internet connectivity.
	 * 
	 * @return true if Internet connection is available otherwise it returns
	 *         false.
	 */
	public static boolean IsNetConnected() {
		boolean m_netConnected = false;
		try {
			ConnectivityManager m_connectivity = (ConnectivityManager) Constants.m_context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			if (m_connectivity == null) {
				Log.w(TAG, "couldn't get connectivity manager");
				m_netConnected = false;
			} else {
				NetworkInfo[] m_info = m_connectivity.getAllNetworkInfo();
				if (m_info != null) {
					for (int i = 0; i < m_info.length; i++) {
						if (m_info[i].getState() == NetworkInfo.State.CONNECTED) {
							m_netConnected = true;
						}
					}
				}
			}
		} catch (Throwable e) {
			// ErrorReporter.getInstance().handleException(e);
			if (Constants.DEBUG) {
				Log.e(TAG, "IsNetConnected Error" + e.toString(), e);

			}
			m_netConnected = false;
		}
		return m_netConnected;
	}

	/**
	 * Method used to retrieve the data from the given HTTP URL and return the
	 * String object.
	 * 
	 * @param p_data
	 *            - Url from which data needs to be retrieved.
	 * @return - Final string received .
	 * @throws IOException
	 *             - When unable to connect or read data from the URL.
	 * @throws CustomException
	 */
	public static synchronized String getData(String p_data, String p_methodName)
			throws CustomException {
		StringBuffer m_stringBuffer = null;
		BufferedReader m_reader;
		try {
			String m_line = null;
			m_reader = new BufferedReader(getResponse(p_data, p_methodName));
			m_stringBuffer = new StringBuffer();
			while ((m_line = m_reader.readLine()) != null) {
				m_stringBuffer.append(m_line);
				m_line = null;
			}
			m_reader = null;
			return m_stringBuffer.toString();
		} catch (IOException te) {
			Log.e(TAG, "Unable to read the data from url:" + p_data, te);
			throw new CustomException(
					Constants.m_context.getString(R.string.unableToOpenConn),
					Constants.CUSTOM_ERROR_CODE, te);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(),
					Constants.CUSTOM_ERROR_CODE, e);
		} finally {
			m_reader = null;
		}
	}

	public static synchronized Reader getResponse(String p_data,
			String p_methodName) throws CustomException {
		if (IsNetConnected()) {

			try {
				HttpURLConnection m_httpConnection = getHttpUrlConnection(m_wsUrl
						+ p_methodName);

				OutputStreamWriter writer = new OutputStreamWriter(
						m_httpConnection.getOutputStream(), "UTF-8");

				writer.write(p_data);
				writer.close();

				Reader m_reader = null;

				if (m_httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
					// read the output from the server
					StringBuffer m_stringBuffer = new StringBuffer();
					if (m_httpConnection.getHeaderField("Content-encoding") != null
							&& m_httpConnection
									.getHeaderField("Content-encoding").trim()
									.toLowerCase().equals("gzip")) {
						m_reader = new InputStreamReader(new GZIPInputStream(
								m_httpConnection.getInputStream()));
					} else {
						m_reader = new InputStreamReader(
								m_httpConnection.getInputStream());
					}
				} else {
					throw new CustomException(
							Constants.m_context
									.getString(R.string.UnableToReadFrmServer),
							Constants.CUSTOM_ERROR_CODE);
				}
				return m_reader;
			} catch (SocketTimeoutException te) {
				Log.e(TAG, "Unable to read the data from url:", te);
				throw new CustomException(
						Constants.m_context
								.getString(R.string.unableToOpenConn),
						Constants.CUSTOM_ERROR_CODE, te);
			} catch (IOException te) {
				Log.e(TAG, "Unable to read the data from url:", te);
				throw new CustomException(
						Constants.m_context
								.getString(R.string.unableToOpenConn),
						Constants.CUSTOM_ERROR_CODE, te);
			}

		} else {
			throw new CustomException(
					Constants.m_context.getString(R.string.InternetConnErr),
					Constants.CUSTOM_ERROR_CODE);
		}
	}
}
