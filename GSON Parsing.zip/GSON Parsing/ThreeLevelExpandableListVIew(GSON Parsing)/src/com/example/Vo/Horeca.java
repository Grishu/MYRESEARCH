package com.example.Vo;

import java.util.List;

public class Horeca extends DetailsVo {
	
	public List<DetailsVo> aziatisch;
	public List<DetailsVo> broodjesSnacks;
	public List<DetailsVo> cafe;
	public List<DetailsVo> frans;
	public List<DetailsVo> grieks;
	public List<DetailsVo> hollands;
	public List<DetailsVo> italiaans;
	public List<DetailsVo> lunchroom;
	public List<DetailsVo> spaans;
	public List<DetailsVo> zalen;

/*	public List<DetailsVo> getAziatisch() {
		return this.aziatisch;
	}

	public void setAziatisch(List<DetailsVo> aziatisch) {
		this.aziatisch = aziatisch;
	}

	public List<DetailsVo> getBroodjesSnacks() {
		return this.broodjesSnacks;
	}

	public void setBroodjesSnacks(List<DetailsVo> broodjesSnacks) {
		this.broodjesSnacks = broodjesSnacks;
	}

	public List<DetailsVo> getCafe() {
		return this.cafe;
	}

	public void setCafe(List<DetailsVo> cafe) {
		this.cafe = cafe;
	}

	public List<DetailsVo> getFrans() {
		return this.frans;
	}

	public void setFrans(List<DetailsVo> frans) {
		this.frans = frans;
	}

	public List<DetailsVo> getGrieks() {
		return this.grieks;
	}

	public void setGrieks(List<DetailsVo> grieks) {
		this.grieks = grieks;
	}

	public List<DetailsVo> getHollands() {
		return this.hollands;
	}

	public void setHollands(List<DetailsVo> hollands) {
		this.hollands = hollands;
	}

	public List<DetailsVo> getItaliaans() {
		return this.italiaans;
	}

	public void setItaliaans(List<DetailsVo> italiaans) {
		this.italiaans = italiaans;
	}

	public List<DetailsVo> getLunchroom() {
		return this.lunchroom;
	}

	public void setLunchroom(List<DetailsVo> lunchroom) {
		this.lunchroom = lunchroom;
	}

	public List<DetailsVo> getSpaans() {
		return this.spaans;
	}

	public void setSpaans(List<DetailsVo> spaans) {
		this.spaans = spaans;
	}

	public List<DetailsVo> getZalen() {
		return this.zalen;
	}

	public void setZalen(List<DetailsVo> zalen) {
		this.zalen = zalen;
	}*/
}
