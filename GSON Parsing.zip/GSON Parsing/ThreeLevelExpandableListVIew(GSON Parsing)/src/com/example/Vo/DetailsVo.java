package com.example.Vo;

public class DetailsVo {
	public String businessID;
	public String businessTitle;
}
