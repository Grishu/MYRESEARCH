package com.example.Vo;

import java.util.ArrayList;
import java.util.List;

public class Winkels extends DetailsVo {
	
	// public DetailsVo boekhandel=new DetailsVo();
	// public Boekhandel boekhandel=new Boekhandel();
	public List<DetailsVo> bodyBeauty = new ArrayList<DetailsVo>();
	public List<DetailsVo> boekhandel = new ArrayList<DetailsVo>();
	public List<DetailsVo> damesmode = new ArrayList<DetailsVo>();
	public List<DetailsVo> diensten = new ArrayList<DetailsVo>();
	public List<DetailsVo> electronica = new ArrayList<DetailsVo>();
	public List<DetailsVo> herenmode = new ArrayList<DetailsVo>();
	public List<DetailsVo> hobbyRecreatie = new ArrayList<DetailsVo>();
	public List<DetailsVo> kindermode = new ArrayList<DetailsVo>();
	public List<DetailsVo> lifestyle = new ArrayList<DetailsVo>();
	public List<DetailsVo> specialisten = new ArrayList<DetailsVo>();
	public List<DetailsVo> speelgoed = new ArrayList<DetailsVo>();
	public List<DetailsVo> verswinkel = new ArrayList<DetailsVo>();

	/*
	 * public List getBodyBeauty() { return this.bodyBeauty; }
	 * 
	 * public void setBodyBeauty(List bodyBeauty) { this.bodyBeauty =
	 * bodyBeauty; }
	 * 
	 * public List getBoekhandel() { return this.boekhandel; }
	 * 
	 * public void setBoekhandel(List<DetailsVo> boekhandel) { this.boekhandel =
	 * boekhandel; }
	 * 
	 * public List getDamesmode() { return this.damesmode; }
	 * 
	 * public void setDamesmode(List<DetailsVo> damesmode) { this.damesmode =
	 * damesmode; }
	 * 
	 * public List getDiensten() { return this.diensten; }
	 * 
	 * public void setDiensten(List diensten) { this.diensten = diensten; }
	 * 
	 * public List getElectronica() { return this.electronica; }
	 * 
	 * public void setElectronica(List electronica) { this.electronica =
	 * electronica; }
	 * 
	 * public List getHerenmode() { return this.herenmode; }
	 * 
	 * public void setHerenmode(List<DetailsVo> herenmode) { this.herenmode =
	 * herenmode; }
	 * 
	 * public List getHobbyRecreatie() { return this.hobbyRecreatie; }
	 * 
	 * public void setHobbyRecreatie(List<DetailsVo> hobbyRecreatie) {
	 * this.hobbyRecreatie = hobbyRecreatie; }
	 * 
	 * public List getKindermode() { return this.kindermode; }
	 * 
	 * public void setKindermode(List<DetailsVo> kindermode) { this.kindermode =
	 * kindermode; }
	 * 
	 * public List getLifestyle() { return this.lifestyle; }
	 * 
	 * public void setLifestyle(List lifestyle) { this.lifestyle = lifestyle; }
	 * 
	 * public List getSpecialisten() { return this.specialisten; }
	 * 
	 * public void setSpecialisten(List specialisten) { this.specialisten =
	 * specialisten; }
	 * 
	 * public List getSpeelgoed() { return this.speelgoed; }
	 * 
	 * public void setSpeelgoed(List speelgoed) { this.speelgoed = speelgoed; }
	 * 
	 * public List getVerswinkel() { return this.verswinkel; }
	 * 
	 * public void setVerswinkel(List verswinkel) { this.verswinkel =
	 * verswinkel; }
	 */
}