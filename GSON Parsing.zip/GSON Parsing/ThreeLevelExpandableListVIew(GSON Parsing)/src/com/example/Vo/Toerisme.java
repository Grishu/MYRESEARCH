package com.example.Vo;

import java.util.List;

public class Toerisme {
	public List<DetailsVo> bBHotels;
	public List<DetailsVo> cultureel;
	public List<DetailsVo> fietsen;
	public List<DetailsVo> monument;
	public List<DetailsVo> museum;
	public List<DetailsVo> publiekeruimte;
	public List<DetailsVo> varen;
	public List<DetailsVo> wandelen;

	/*public List getBBHotels() {
		return this.bBHotels;
	}

	public void setBBHotels(List bBHotels) {
		this.bBHotels = bBHotels;
	}

	public List getCultureel() {
		return this.cultureel;
	}

	public void setCultureel(List cultureel) {
		this.cultureel = cultureel;
	}

	public List getFietsen() {
		return this.fietsen;
	}

	public void setFietsen(List fietsen) {
		this.fietsen = fietsen;
	}

	public List getMonument() {
		return this.monument;
	}

	public void setMonument(List monument) {
		this.monument = monument;
	}

	public List getMuseum() {
		return this.museum;
	}

	public void setMuseum(List museum) {
		this.museum = museum;
	}

	public List getPubliekeruimte() {
		return this.publiekeruimte;
	}

	public void setPubliekeruimte(List publiekeruimte) {
		this.publiekeruimte = publiekeruimte;
	}

	public List getVaren() {
		return this.varen;
	}

	public void setVaren(List varen) {
		this.varen = varen;
	}

	public List getWandelen() {
		return this.wandelen;
	}

	public void setWandelen(List wandelen) {
		this.wandelen = wandelen;
	}*/
}