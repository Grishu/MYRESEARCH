package com.example.Vo;

public class ShopVo {

	public String m_Id, m_ShopName, m_Starred, m_discount_Text;

}
