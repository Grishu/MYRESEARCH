package com.example.Vo;


public class ShopMasterOntdek {
	public Horeca horeca=new Horeca();
	public Toerisme toerisme=new Toerisme();
	public Winkels winkels=new Winkels();

}
